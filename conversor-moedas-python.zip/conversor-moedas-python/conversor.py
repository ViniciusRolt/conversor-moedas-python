
import requests
import json
import os
from datetime import datetime

CACHE_FILE = "cache.json"

def carregar_cache():
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    return {}

def salvar_cache(dados):
    with open(CACHE_FILE, "w") as f:
        json.dump(dados, f)

def obter_taxa(base="BRL", destino="USD"):
    url = f"https://api.exchangerate.host/latest?base={base}&symbols={destino}"
    try:
        resposta = requests.get(url)
        dados = resposta.json()
        taxa = dados["rates"][destino]
        salvar_cache({
            "base": base,
            "destino": destino,
            "taxa": taxa,
            "data": datetime.now().isoformat()
        })
        return taxa
    except:
        print("Erro ao acessar API, tentando usar cache...")
        cache = carregar_cache()
        if cache.get("base") == base and cache.get("destino") == destino:
            return cache["taxa"]
        else:
            print("Sem taxa válida no cache.")
            return None

def converter():
    base = input("Moeda base (ex: BRL): ").upper()
    destino = input("Moeda destino (ex: USD): ").upper()
    valor = float(input(f"Valor em {base}: "))

    taxa = obter_taxa(base, destino)
    if taxa:
        convertido = valor * taxa
        print(f"{valor:.2f} {base} = {convertido:.2f} {destino}")
    else:
        print("Não foi possível realizar a conversão.")

if __name__ == "__main__":
    converter()
